All application code copied from Lecture33-1.5.8.
