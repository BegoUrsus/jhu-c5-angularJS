(function () {
'use strict';

angular.module('ShoppingList', ['ui.router', 'Spinner']);

})();
